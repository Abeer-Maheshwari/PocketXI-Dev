# main.py
import asyncio
import os
import sys
import pygame
from src.launcher import GameLauncher
from src.match import MatchController
from src.network import NetworkClient
from src.transition import TransitionManager
from src.ui import MenuSystem

IS_WASM = sys.platform in ("emscripten", "wasi")

pygame.mixer.pre_init(frequency=24000, size=-16, channels=2, buffer=2048)


async def main():
    """Application entry point managing the menu loop and match lifecycle."""
    launcher_backend = GameLauncher()
    network_client = NetworkClient("ws://152.67.155.250:8765")
    asyncio.create_task(network_client.connect())
    menu_system = MenuSystem(launcher_backend, network_client=network_client)

    transition = TransitionManager(menu_system.screen)

    # Initial menu draw
    menu_system.renderDisplay()
    previous_menu_state = menu_system.current_state

    while True:
        launch_mode = None

        # Menu navigation loop
        while not launch_mode:
            if not IS_WASM:
                menu_system.clock.tick(60)

            signal = await menu_system.processEvents()

            if signal == "LAUNCH_MATCH":
                launch_mode = "OFFLINE"
                break
            elif signal == "LAUNCH_ONLINE_MATCH":
                launch_mode = "ONLINE"
                break

            menu_system.renderDisplay()
            await asyncio.sleep(0)

        # Fade out menu before entering match
        if launch_mode != "ONLINE" and not IS_WASM:
            await transition.fade_out(draw_current_fn=menu_system.renderDisplay, duration=0.25)

        # Match launch and setup
        if launch_mode == "ONLINE":
            game = MatchController(
                launcher_backend=launcher_backend,
                menu_system=menu_system,
                network_client=network_client,
                is_online=True,
            )
        else:
            if not IS_WASM:
                await transition.show_loading(
                    title="LOADING MATCH...",
                    subtitle="Initializing heuristic AI engine",
                    min_duration=0.5,
                )
            game = MatchController(
                launcher_backend=launcher_backend,
                menu_system=menu_system,
                is_online=False,
            )

        # Run active match loop
        await game.runMatchLoop()

        # Fade out match upon exit
        if launch_mode != "ONLINE" and not IS_WASM:
            await transition.fade_out(draw_current_fn=game.renderScene, duration=0.25)

        # Restore menu state
        menu_system.current_state = "MAIN_HUB"
        previous_menu_state = "MAIN_HUB"
        if network_client:
            network_client.match_started = False
            network_client.room_code = None

        menu_system.renderDisplay()
        await asyncio.sleep(0)


if __name__ == "__main__":
    asyncio.run(main())